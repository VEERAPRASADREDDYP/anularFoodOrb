export interface ICustomerDetails{
    id:number,
    email:string,
    password:string,
    cpassword:string
}