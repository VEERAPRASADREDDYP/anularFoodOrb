export interface ICart{
    email:string,
    dishName:string,
    cost:number,
    isInCart:boolean
}