import { Component, OnInit } from '@angular/core';
import { ICart } from 'src/app/models/Cart.model';
import { CartService } from 'src/app/services/cart.service';

@Component({
  selector: 'app-place-order',
  templateUrl: './place-order.component.html',
  styleUrls: ['./place-order.component.css']
})
export class PlaceOrderComponent implements OnInit {

  public cartDetails:ICart[]=[];

  public orderId:number;

  constructor(private cartService:CartService) { }

  ngOnInit(): void {
    this.orderId = Math.random()
    this.cartService.getCartDetails().subscribe(
      (response)=>{
        this.cartDetails = response;
        console.log('cart details in purchase',this.cartDetails);
        this.updateCartDetails(this.cartDetails);
      }
    )
  }

  public updateCartDetails(data){
    for(let i=0;i<data.length;i++){
      console.log(data[i])
      if(data[i].isInCart == true){
        data[i].isInCart = false;
        this.cartService.updateCartDetail(data[i]);
      }
    }
  }

}
