import { Component, Input, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ICart } from 'src/app/models/Cart.model';
import { IFoodList } from 'src/app/models/foodList.model';
import { CartService } from 'src/app/services/cart.service';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {

  public foodRecord: IFoodList;

  public total: number;

  @Input() email:string;

  public cartDetails : ICart[]=[];

  public requiredCartDetails : ICart[]=[];

  constructor(private cartService: CartService) {
    this.total = 0;
   }

  ngOnInit(): void {
    console.log(this.email)
    this.cartService.getCartDetails().subscribe(
      (response)=>{
        this.cartDetails = response
        console.log('in cart response',this.cartDetails)
        this.getRequiredCartDetails(this.cartDetails,this.total);

      }
    )
  }

  public getRequiredCartDetails(data:ICart[],total){
    console.log('in cart component',data)
    for(let i=0;i<data.length;i++){
        if(data[i].isInCart == true){
         this.total = this.total + data[i].cost;
          this.requiredCartDetails.push(data[i])
        }
    }
    console.log('required details',this.requiredCartDetails,total)
  }

}
