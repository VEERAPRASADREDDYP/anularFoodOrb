import { Component, Input, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ICart } from 'src/app/models/Cart.model';
import { IFoodList } from 'src/app/models/foodList.model';
import { CartService } from 'src/app/services/cart.service';
import { OrdersService } from 'src/app/services/orders.service';

@Component({
  selector: 'app-customer-content',
  templateUrl: './customer-content.component.html',
  styleUrls: ['./customer-content.component.css']
})
export class CustomerContentComponent implements OnInit {

  public foodList:IFoodList[]=[];

  public foodRecord:any;

  public searchFood:number;

  public CartItem=<ICart>{};

  @Input() email:string;


  constructor(private ordersService: OrdersService,private cartService:CartService) { }

  ngOnInit(): void {
    this.ordersService.getFoodList().subscribe(
      (response)=>{
        this.foodList=response;
        console.log("food list::",this.foodList)
      }
    )

  }

  public addToCart(foodRecord : IFoodList){
    this.CartItem.dishName = foodRecord.dishName;
    this.CartItem.cost = foodRecord.cost;
    this.CartItem.email = this.email;
    this.CartItem.isInCart = true;      
    this.cartService.onAddToCart(this.CartItem);
  }

  public getParticualarFood():void{
    this.ordersService.getParticularFood(this.searchFood).subscribe((record:any)=>{
   
      console.log(record)
      this.foodRecord = record[0];
    })
  }

}
