import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ICustomerDetails } from 'src/app/models/Customer.model';
import { CustomerServiceService } from 'src/app/services/customer-service.service';

@Component({
  selector: 'app-customer-account',
  templateUrl: './customer-account.component.html',
  styleUrls: ['./customer-account.component.css']
})
export class CustomerAccountComponent implements OnInit {

   customer: ICustomerDetails[]=[];

   isPasswordCorrect: boolean;

  constructor(private customerService: CustomerServiceService, private router: Router) { 
    
  }

  ngOnInit(): void {
    this.isPasswordCorrect=true;
    this.customerService.getDetails().subscribe(
      (response) => {
        this.customer=response;
        console.log('response:::',this.customer)
      }   
    )
  }

  public onSubmit(data: ICustomerDetails){
    let p=0;
      console.log(data);
      for(let i=0;i<this.customer.length;i++){
          console.log(this.customer[i]);
          if(this.customer[i].email === data.email && this.customer[i].password === data.password){
            console.log('success');
            p=1;
          }
          else{
            //console.log("faliure")
          }
      }

      if(p==1){
          this.router.navigate(['/loggedIn'],{
            queryParams:{
              email:data.email
            }, skipLocationChange:true
          });
      }
      else
      {
        this.isPasswordCorrect = false;
      }
  }

}
