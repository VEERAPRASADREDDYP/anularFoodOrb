import { Component, OnInit } from '@angular/core';
import { ICustomerDetails } from 'src/app/models/Customer.model';
import { CustomerServiceService } from 'src/app/services/customer-service.service';

@Component({
  selector: 'app-reset-password',
  templateUrl: './reset-password.component.html',
  styleUrls: ['./reset-password.component.css']
})
export class ResetPasswordComponent implements OnInit {

  customer: ICustomerDetails[]=[];

  constructor(private customerService: CustomerServiceService) { }

  ngOnInit(): void {
    this.customerService.getDetails().subscribe(
      (response)=>
      this.customer=response

    )
  }

  public onSubmit(data){
      if(data.password === data.cpassword){
        for(let i=0;i<this.customer.length;i++){
          if(data.email === this.customer[i].email){
            alert("Reset password success");

            data.id = this.customer[i].id;
            this.customerService.updateDetails(this.customer[i].id,data);
            console.log("submitted for reset:",data,this.customer[i].id)
          }
        }
      }
  }
}
