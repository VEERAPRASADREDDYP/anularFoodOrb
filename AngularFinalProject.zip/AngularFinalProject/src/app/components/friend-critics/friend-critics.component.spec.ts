import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FriendCriticsComponent } from './friend-critics.component';

describe('FriendCriticsComponent', () => {
  let component: FriendCriticsComponent;
  let fixture: ComponentFixture<FriendCriticsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FriendCriticsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FriendCriticsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
