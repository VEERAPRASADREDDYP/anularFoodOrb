import { Component, OnInit } from '@angular/core';
import { ICustomerDetails } from 'src/app/models/Customer.model';
import { CustomerServiceService } from 'src/app/services/customer-service.service';

@Component({
  selector: 'app-friend-critics',
  templateUrl: './friend-critics.component.html',
  styleUrls: ['./friend-critics.component.css']
})
export class FriendCriticsComponent implements OnInit {

  

  public customerDetails:ICustomerDetails[]=[];

  constructor(private customerService:CustomerServiceService) { }

  ngOnInit(): void {
    this.customerService.getDetails().subscribe(
      (response)=>{
          this.customerDetails = response;
      }
    )
  }

}
