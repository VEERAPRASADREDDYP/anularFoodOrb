import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ICustomerDetails } from 'src/app/models/Customer.model';

@Component({
  selector: 'app-after-login',
  templateUrl: './after-login.component.html',
  styleUrls: ['./after-login.component.css']
})
export class AfterLoginComponent implements OnInit {

  public customerDetail: ICustomerDetails;

  constructor(private activatedRoute: ActivatedRoute) {
    this.customerDetail={} as ICustomerDetails;
   }

  ngOnInit(): void {
    this.activatedRoute.queryParamMap.subscribe((params:any)=>{
      this.customerDetail.email = params.get('email');
      console.log(this.customerDetail.email)
    })


  }

}
