import { Component, OnInit } from '@angular/core';
import { ICustomerDetails } from 'src/app/models/Customer.model';
import { CustomerServiceService } from 'src/app/services/customer-service.service';

@Component({
  selector: 'app-customer-registration',
  templateUrl: './customer-registration.component.html',
  styleUrls: ['./customer-registration.component.css']
})
export class CustomerRegistrationComponent implements OnInit {

  public customer:ICustomerDetails[]=[];

  public isPasswordMatched:boolean;

  public customerData=<ICustomerDetails>{};

  constructor(private customerService: CustomerServiceService) { }

  ngOnInit(): void {
    this.isPasswordMatched = false;
  }

  public onRegister(data){
    if(data.password === data.cpassword){
      this.customerData.email = data.email;
    this.customerData.password = data.password;
    this.customerData.cpassword = data.cpassword;
    alert("Regisetred successfully");
    this.customerService.onRegister(this.customerData);
    }
    else{
      this.isPasswordMatched=true;
    }
    
    
  }

}
