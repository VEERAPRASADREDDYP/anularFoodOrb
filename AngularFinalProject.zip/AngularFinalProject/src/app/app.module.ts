import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { CustomerAccountComponent } from './components/customer-account/customer-account.component';
import { AdminAccountComponent } from './components/admin-account/admin-account.component';
import { HomeComponent } from './components/home/home.component';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { CustomerContentComponent } from './components/customer-content/customer-content.component';
import { ResetPasswordComponent } from './components/reset-password/reset-password.component';
import { CustomerRegistrationComponent } from './components/customer-registration/customer-registration.component';
import { AfterLoginComponent } from './components/after-login/after-login.component';
import { CartComponent } from './components/cart/cart.component';
import { PlaceOrderComponent } from './components/place-order/place-order.component';
import { FriendCriticsComponent } from './components/friend-critics/friend-critics.component';

@NgModule({
  declarations: [
    AppComponent,
    CustomerAccountComponent,
    AdminAccountComponent,
    HomeComponent,
    CustomerContentComponent,
    ResetPasswordComponent,
    CustomerRegistrationComponent,
    AfterLoginComponent,
    CartComponent,
    PlaceOrderComponent,
    FriendCriticsComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
