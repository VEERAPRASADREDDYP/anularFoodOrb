import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AdminAccountComponent } from './components/admin-account/admin-account.component';
import { AfterLoginComponent } from './components/after-login/after-login.component';
import { CartComponent } from './components/cart/cart.component';
import { CustomerAccountComponent } from './components/customer-account/customer-account.component';
import { CustomerContentComponent } from './components/customer-content/customer-content.component';
import { CustomerRegistrationComponent } from './components/customer-registration/customer-registration.component';
import { FriendCriticsComponent } from './components/friend-critics/friend-critics.component';
import { HomeComponent } from './components/home/home.component';
import { PlaceOrderComponent } from './components/place-order/place-order.component';
import { ResetPasswordComponent } from './components/reset-password/reset-password.component';


const routes: Routes = [
//  {path: '', redirectTo:'home',pathMatch:'full'},
  {path:'',component:HomeComponent},  
  {path:'AdminAccount',component:AdminAccountComponent},
  {path:'CustomerAccount',component:CustomerAccountComponent},
  {path:'reset-password',component:ResetPasswordComponent},
  {path:'customer-registration',component:CustomerRegistrationComponent},
  {path:'loggedIn',component:AfterLoginComponent,
  children:[
  {path:'',component:CustomerContentComponent},
  {path:'Customer-content',component:CustomerContentComponent},
  {path:'cart',component:CartComponent},
  {path:'placeOrder',component:PlaceOrderComponent},
  {path:'critics',component:FriendCriticsComponent}
]}
 
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
