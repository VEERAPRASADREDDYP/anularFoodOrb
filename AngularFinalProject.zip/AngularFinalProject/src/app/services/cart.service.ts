import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ICart } from '../models/Cart.model';


@Injectable({
  providedIn: 'root'
})
export class CartService {

  constructor(private http: HttpClient) { }

  public onAddToCart(data){
    return this.http.post('http://localhost:3000/cart',data).subscribe(
      (response)=>{
        console.log(response);
      },
      (error)=>{
        console.log("Erroro occured"+error)
      }
    )
  }

  public getCartDetails(){
    return this.http.get<ICart[]>('http://localhost:3000/cart');
  }

  public updateCartDetail(data){
    return  this.http.put('http://localhost:3000/cart/'+data.id, data).subscribe(
      (response)=>
      {
        console.log(response);
      }
    )
  }

}
