import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ICustomerDetails } from '../models/Customer.model';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CustomerServiceService {

  constructor(private http: HttpClient) { }

  public getDetails():Observable<any>{
    return this.http.get('http://localhost:3000/users');
  }

  public updateDetails(id:number,data:ICustomerDetails){
    console.log("submitted for reset in service:",data,id)
    return this.http.put('http://localhost:3000/users/'+id, data).subscribe(
      (response)=>{
        console.log(response)
      }
    )
  }

  public onRegister(data){
    return this.http.post('http://localhost:3000/users',data).subscribe(
      (response)=>{
        console.log(response);
      },
      (error)=>{
        console.log("Erroro occured"+error)
      }
    )
  }


}
