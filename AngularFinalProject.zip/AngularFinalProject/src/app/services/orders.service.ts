import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { IFoodList } from '../models/foodList.model';

@Injectable({
  providedIn: 'root'
})
export class OrdersService {

  constructor(private http:HttpClient) { }

  public getFoodList(){
    return this.http.get<IFoodList[]>('http://localhost:3000/foodList')
  }

  public getParticularFood(id:any) {
    return this.http.get(`http://localhost:3000/foodList?feedId=${id}`)
  }
}
